<?php

$koneksi = new mysqli("localhost", "root", "", "db_tokoonline");