<h2>Selamat datang Administrator</h2>
<br><center><p>Repost by <a href='https://stokcoding.com/' title='StokCoding.com' target='_blank'>StokCoding.com</a></p></center>


<!-- <pre> -->
  <?php // print_r($_SESSION); ?>
<!-- </pre> -->