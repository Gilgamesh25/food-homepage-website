-- MySQL dump 10.13  Distrib 5.7.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: db_tokoonline
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.38-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin','admin','Administrator');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;

--
-- Table structure for table `kategori`
--

DROP TABLE IF EXISTS `kategori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kategori` (
  `id_kategori` int(5) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(100) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kategori`
--

/*!40000 ALTER TABLE `kategori` DISABLE KEYS */;
INSERT INTO `kategori` VALUES (1,'Kategori A'),(2,'Kategori B');
/*!40000 ALTER TABLE `kategori` ENABLE KEYS */;

--
-- Table structure for table `ongkir`
--

DROP TABLE IF EXISTS `ongkir`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ongkir` (
  `id_ongkir` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kota` varchar(100) NOT NULL,
  `tarif` int(11) NOT NULL,
  PRIMARY KEY (`id_ongkir`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ongkir`
--

/*!40000 ALTER TABLE `ongkir` DISABLE KEYS */;
INSERT INTO `ongkir` VALUES (1,'Demak',20000),(2,'Cirebon',30000);
/*!40000 ALTER TABLE `ongkir` ENABLE KEYS */;

--
-- Table structure for table `pelanggan`
--

DROP TABLE IF EXISTS `pelanggan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pelanggan` (
  `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT,
  `email_pelanggan` varchar(100) NOT NULL,
  `password_pelanggan` varchar(50) NOT NULL,
  `nama_pelanggan` varchar(100) NOT NULL,
  `telepon_pelanggan` varchar(100) NOT NULL,
  `alamat_pelanggan` text NOT NULL,
  PRIMARY KEY (`id_pelanggan`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pelanggan`
--

/*!40000 ALTER TABLE `pelanggan` DISABLE KEYS */;
INSERT INTO `pelanggan` VALUES (1,'doddy@gmail.com','doddy','Doddy Setiawan','08888123123',''),(2,'erik@gmail.com','erik','Erik Candra','0888111111',''),(3,'yudi@contoh.com','1234','Yudi Saputra','0746356643','Jogja'),(4,'doni@contoh.com','1234','Doni','0761888888','Semarang'),(5,'erwin@contoh.com','1234','Erwin','088867553','Demak');
/*!40000 ALTER TABLE `pelanggan` ENABLE KEYS */;

--
-- Table structure for table `pembayaran`
--

DROP TABLE IF EXISTS `pembayaran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pembayaran` (
  `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT,
  `id_pembelian` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `bank` varchar(255) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `bukti` varchar(255) NOT NULL,
  PRIMARY KEY (`id_pembayaran`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pembayaran`
--

/*!40000 ALTER TABLE `pembayaran` DISABLE KEYS */;
INSERT INTO `pembayaran` VALUES (4,11,'Erik','Mandiri',2020000,'2020-08-05','20200805165815tugas3.png'),(5,13,'Erik','Mandiri',6020000,'2020-08-08','20200808173932punya-putri.png'),(6,18,'Doni','Mandiri',6044000,'2020-09-15','20200915032134database.png'),(7,19,'Erwin','Mandiri',3024000,'2020-09-15','20200915045855database.png');
/*!40000 ALTER TABLE `pembayaran` ENABLE KEYS */;

--
-- Table structure for table `pembelian`
--

DROP TABLE IF EXISTS `pembelian`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pembelian` (
  `id_pembelian` int(11) NOT NULL AUTO_INCREMENT,
  `id_pelanggan` int(11) NOT NULL,
  `tanggal_pembelian` date NOT NULL,
  `total_pembelian` int(11) NOT NULL,
  `alamat_pengiriman` text NOT NULL,
  `status_pembelian` varchar(100) NOT NULL DEFAULT 'pending',
  `resi_pengiriman` varchar(50) NOT NULL,
  `totalberat` int(11) NOT NULL,
  `provinsi` varchar(255) NOT NULL,
  `distrik` varchar(255) NOT NULL,
  `tipe` varchar(255) NOT NULL,
  `kodepos` varchar(255) NOT NULL,
  `ekspedisi` varchar(255) NOT NULL,
  `paket` varchar(255) NOT NULL,
  `ongkir` int(11) NOT NULL,
  `estimasi` varchar(255) NOT NULL,
  PRIMARY KEY (`id_pembelian`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pembelian`
--

/*!40000 ALTER TABLE `pembelian` DISABLE KEYS */;
INSERT INTO `pembelian` VALUES (1,1,'2020-07-25',1500000,'','pending','',0,'','','','','','',0,''),(2,1,'2020-07-26',500000,'','pending','',0,'','','','','','',0,''),(6,1,'2020-07-29',2520000,'','pending','',0,'','','','','','',0,''),(7,1,'2020-07-29',2520000,'','pending','',0,'','','','','','',0,''),(8,1,'2020-07-29',2530000,'','pending','',0,'','','','','','',0,''),(9,2,'2020-08-01',1520000,'','pending','',0,'','','','','','',0,''),(10,2,'2020-08-01',1520000,'','pending','',0,'','','','','','',0,''),(11,2,'2020-08-01',2020000,'','barang dikirim','abc123',0,'','','','','','',0,''),(12,2,'2020-08-01',2020000,'jl. Serayu kode pos: 5611122','pending','',0,'','','','','','',0,''),(13,2,'2020-08-08',6020000,'Waru ','sudah kirim pembayaran','',0,'','','','','','',0,''),(16,3,'2020-08-15',8030000,'Jl. Sultan, Cirebon','pending','',0,'','','','','','',0,''),(17,3,'2020-09-13',6024000,'Jl. Hastina 2 Wedomartani Sleman','pending','',4000,'DI Yogyakarta','Sleman','Kabupaten','55513','jne','CTC',24000,'1-2'),(18,4,'2020-09-15',6044000,'jl. Pemuda 287 Semarang','barang dikirim','smg000343',4000,'Jawa Tengah','Semarang','Kota','50135','jne','REG',44000,'2-3'),(19,5,'2020-09-15',3024000,'jl. Sedayu no 14 Demak','barang dikirim','Dmk0034345',2000,'Jawa Tengah','Demak','Kabupaten','59519','jne','OKE',24000,'6-7');
/*!40000 ALTER TABLE `pembelian` ENABLE KEYS */;

--
-- Table structure for table `pembelian_produk`
--

DROP TABLE IF EXISTS `pembelian_produk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pembelian_produk` (
  `id_pembelian_produk` int(11) NOT NULL AUTO_INCREMENT,
  `id_pembelian` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `harga` int(11) NOT NULL,
  `berat` int(11) NOT NULL,
  `subberat` int(11) NOT NULL,
  `subharga` int(11) NOT NULL,
  PRIMARY KEY (`id_pembelian_produk`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pembelian_produk`
--

/*!40000 ALTER TABLE `pembelian_produk` DISABLE KEYS */;
INSERT INTO `pembelian_produk` VALUES (1,1,1,1,'',0,0,0,0),(2,1,2,1,'',0,0,0,0),(3,7,1,2,'',0,0,0,0),(4,7,2,1,'',0,0,0,0),(5,8,1,2,'',0,0,0,0),(6,8,2,1,'',0,0,0,0),(7,9,1,1,'',0,0,0,0),(8,9,2,1,'',0,0,0,0),(9,10,1,1,'Laptop Asus xix',1000000,1000,1000,1000000),(10,10,2,1,'Laptop Acer 212',500000,1000,1000,500000),(11,11,1,1,'Laptop Asus xix',1500000,1000,1000,1500000),(12,11,2,1,'Laptop Acer 212',500000,1000,1000,500000),(13,0,1,1,'Laptop Asus xix',1500000,1000,1000,1500000),(14,0,2,1,'Laptop Acer 212',500000,1000,1000,500000),(15,12,1,1,'Laptop Asus xix',1500000,1000,1000,1500000),(16,12,2,1,'Laptop Acer 212',500000,1000,1000,500000),(17,13,2,2,'Laptop Acer 212',500000,1000,2000,1000000),(18,13,3,2,'Laptop macbook 212',2500000,1200,2400,5000000),(23,16,3,2,'Laptop macbook 212',2500000,1200,2400,5000000),(24,16,4,1,'Laptop Pro',3000000,2000,2000,3000000),(25,17,4,2,'Laptop Pro',3000000,2000,4000,6000000),(26,18,4,2,'Laptop Pro',3000000,2000,4000,6000000),(27,19,1,2,'Laptop Asus xix',1500000,1000,2000,3000000);
/*!40000 ALTER TABLE `pembelian_produk` ENABLE KEYS */;

--
-- Table structure for table `produk`
--

DROP TABLE IF EXISTS `produk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL AUTO_INCREMENT,
  `id_kategori` int(5) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `harga_produk` int(11) NOT NULL,
  `berat_produk` int(11) NOT NULL,
  `foto_produk` varchar(100) NOT NULL,
  `deskripsi_produk` text NOT NULL,
  `stok_produk` int(5) NOT NULL,
  PRIMARY KEY (`id_produk`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produk`
--

/*!40000 ALTER TABLE `produk` DISABLE KEYS */;
INSERT INTO `produk` VALUES (1,1,'Laptop Asus xix',1500000,1000,'kari-shea-1SAnrIxw5OY-unsplash.jpg','Ini asus bagus',3),(2,1,'Laptop Acer 212',500000,1000,'sora-sagano-WFSap6CIXuw-unsplash (1).jpg','Ini Acer bagus',3),(3,2,'Laptop macbook 212',2500000,1200,'ben-kolde-t9DooibgMEk-unsplash.jpg','Ini macbook bagus bergaransi',3),(4,2,'Laptop Pro',3000000,2000,'kitai-jogia-zhvaeh-R9rA-unsplash.jpg','Laptop pro',3),(5,1,'ASD edited',500000,50,'p5290175.jpg','                    asdasd    asd            ',10),(6,2,'Buku Koding',60000,600,'sincerely-media-CXYPfveiuis-unsplash.jpg','Buku koding terbaru',10);
/*!40000 ALTER TABLE `produk` ENABLE KEYS */;

--
-- Table structure for table `produk_foto`
--

DROP TABLE IF EXISTS `produk_foto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produk_foto` (
  `id_produk_foto` int(11) NOT NULL AUTO_INCREMENT,
  `id_produk` int(11) NOT NULL,
  `nama_produk_foto` varchar(255) NOT NULL,
  PRIMARY KEY (`id_produk_foto`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produk_foto`
--

/*!40000 ALTER TABLE `produk_foto` DISABLE KEYS */;
INSERT INTO `produk_foto` VALUES (2,8,'vinicius-amnx-amano-fdiXdOdYtLE-unsplash.jpg'),(3,8,'sincerely-media-CXYPfveiuis-unsplash.jpg'),(5,8,'20200905085618sincerely-media-CXYPfveiuis-unsplash.jpg'),(6,6,'sincerely-media-CXYPfveiuis-unsplash.jpg');
/*!40000 ALTER TABLE `produk_foto` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-12 10:04:37
